import React, { Component } from 'react';
import Form from '../components/Form';


class Home extends Component {
  render() {
    //For the form to populate on the home page
    return (
        <div>
        <Form />
        </div>
    );
  }
}

export default Home;
