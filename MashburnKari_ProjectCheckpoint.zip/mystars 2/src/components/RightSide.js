import React, { Component } from 'react';

class RightSide extends Component {
    state = {
      data: []
    };
  
  render() {
    return (
      <section>
      <h4>Horoscope Contet Goes Here</h4>
      </section>
    );
  }
}

export default RightSide;
