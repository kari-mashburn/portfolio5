import React, { Component } from 'react';
import '../App.css';

class FAQ extends Component {
  render() {
    return (
      <section>
      <p>FAQ Stuff Goes Here. Coming Soon</p>
      </section>
    );
  }
}

export default FAQ;
