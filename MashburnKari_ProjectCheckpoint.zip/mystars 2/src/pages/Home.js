import React, { Component } from 'react';
import Form from '../components/Form';


class Home extends Component {
  render() {
    return (
        <div>
        <Form />
        </div>
    );
  }
}

export default Home;
